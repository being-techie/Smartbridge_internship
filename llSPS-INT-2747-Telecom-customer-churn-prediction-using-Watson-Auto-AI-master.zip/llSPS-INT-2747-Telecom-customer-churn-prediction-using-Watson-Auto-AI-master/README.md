# llSPS-INT-2747-Telecom-customer-churn-prediction-using-Watson-Auto-AI
Telecom customer churn prediction using Watson Auto AI

For this Project you will need

IBM Cloud account, that will be used for deployment
IBM Watson services like Watson Auto AI and
Node-red Service For UI 
